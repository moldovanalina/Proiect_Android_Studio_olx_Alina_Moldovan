package com.example.olx;

public class Anunt{
    public String owner;//a cui e anuntul, userul
    public String categorie;
    public String titlu;
    public String info;
    public String telefon;


}
